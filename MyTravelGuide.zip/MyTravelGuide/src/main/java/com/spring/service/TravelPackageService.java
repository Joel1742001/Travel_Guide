package com.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.ActivityRepository;
import com.spring.dao.TravelPackageRepository;
import com.spring.entity.Activity;
import com.spring.entity.Destination;
import com.spring.entity.Passenger;
import com.spring.entity.TravelPackage;

import jakarta.transaction.Transactional;

@Service
public class TravelPackageService {

	@Autowired
	private TravelPackageRepository travelPackageRepository;
	@Autowired
	private ActivityRepository activityRepository;

	@Transactional
	public TravelPackage saveTravelPackage(TravelPackage travelPackage) {
	    // Iterate through the itinerary and ensure activities are managed
	    for (Destination destination : travelPackage.getItinerary()) {
	        for (Activity activity : destination.getActivities()) {
	            if (activity.getId() != null) {
	                // If activity ID is not null, retrieve the managed entity
	                Optional<Activity> optionalActivity = activityRepository.findById(activity.getId());
	                if (optionalActivity.isPresent()) {
	                    activity = optionalActivity.get();
	                } else {
	                    // Handle the case when activity is not found
	                    throw new IllegalArgumentException("Activity with ID " + activity.getId() + " not found");
	                }
	            }
	        }
	    }
	    
	    // Save the TravelPackage
	    return travelPackageRepository.save(travelPackage);
	}





	public List<TravelPackage> getAllTravelPackages() {
		return travelPackageRepository.findAll();
	}

	public TravelPackage getTravelPackageById(Long id) {
		return travelPackageRepository.findById(id).orElse(null);
	}

	public void deleteTravelPackage(Long id) {
		travelPackageRepository.deleteById(id);
	}

	// Additional features

	public String printItinerary(Long travelPackageId) {
		TravelPackage travelPackage = getTravelPackageById(travelPackageId);
		if (travelPackage == null) {
			return "Travel Package not found!";
		}

		StringBuilder itinerary = new StringBuilder();
		itinerary.append("Itinerary of ").append(travelPackage.getName()).append(":\n");
		for (Destination destination : travelPackage.getItinerary()) {
			itinerary.append("Destination: ").append(destination.getName()).append("\n");
			for (Activity activity : destination.getActivities()) {
				itinerary.append("  Activity: ").append(activity.getName()).append("\n").append("    Description: ")
						.append(activity.getDescription()).append("\n").append("    Cost: ").append(activity.getCost())
						.append("\n").append("    Capacity: ").append(activity.getCapacity()).append("\n\n");
			}
		}
		return itinerary.toString();
	}

	public String printPassengerList(Long travelPackageId) {
		TravelPackage travelPackage = getTravelPackageById(travelPackageId);
		if (travelPackage == null) {
			return "Travel Package not found!";
		}

		StringBuilder passengerList = new StringBuilder();
		passengerList.append("Passenger list of ").append(travelPackage.getName()).append(":\n")
				.append("Package capacity: ").append(travelPackage.getCapacity()).append("\n")
				.append("Number of passengers currently enrolled: ").append(travelPackage.getPassengers().size())
				.append("\n");

		for (Passenger passenger : travelPackage.getPassengers()) {
			passengerList.append("Passenger: ").append(passenger.getName()).append(" (Number: ")
					.append(passenger.getPassengerNumber()).append(")\n");
		}
		return passengerList.toString();
	}

	
	public String printAvailableActivities(Long travelPackageId) {
		TravelPackage travelPackage = getTravelPackageById(travelPackageId);
		if (travelPackage == null) {
			return "Travel Package not found!";
		}

		StringBuilder availableActivities = new StringBuilder();
		availableActivities.append("Available Activities:\n");
		for (Destination destination : travelPackage.getItinerary()) {
			for (Activity activity : destination.getActivities()) {
				int remainingCapacity = activity.getCapacity() - travelPackage.getPassengers().size();
				if (remainingCapacity > 0) {
					availableActivities.append("Activity: ").append(activity.getName()).append("\n")
							.append("Description: ").append(activity.getDescription()).append("\n")
							.append("Remaining Capacity: ").append(remainingCapacity).append("\n\n");
				}
			}
		}
		return availableActivities.toString();
	}
	
	 public String printPassengerDetails(Long travelPackageId, Long passengerId) {
	        TravelPackage travelPackage = travelPackageRepository.findById(travelPackageId).orElse(null);
	        if (travelPackage == null) {
	            return "Travel Package not found!";
	        }

	        Passenger passenger = travelPackage.getPassengers().stream()
	                .filter(p -> p.getId().equals(passengerId))
	                .findFirst().orElse(null);

	        if (passenger == null) {
	            return "Passenger not found!";
	        }

	        StringBuilder passengerDetails = new StringBuilder();
	        passengerDetails.append("Details of Passenger ").append(passenger.getName()).append(":\n")
	                .append("Name: ").append(passenger.getName()).append("\n")
	                .append("Passenger Number: ").append(passenger.getPassengerNumber()).append("\n");

	        if (passenger.getBalance() != 0.0) {
	            passengerDetails.append("Balance: ").append(passenger.getBalance()).append("\n");
	        }

	        if (!passenger.getActivities().isEmpty()) {
	            passengerDetails.append("Activities:\n");
	            for (Activity activity : passenger.getActivities()) {
	                passengerDetails.append("  Activity: ").append(activity.getName()).append("\n")
	                        .append("    Destination: ").append(activity.getDestination().getName()).append("\n")
	                        .append("    Price Paid: ").append(activity.getCost()).append("\n\n");
	            }
	        }

	        return passengerDetails.toString();
	    }

}
