package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.DestinationRepository;
import com.spring.entity.Destination;

	@Service
	public class DestinationService {

	    @Autowired
	    private DestinationRepository destinationRepository;

	    public Destination saveDestination(Destination destination) {
	        return destinationRepository.save(destination);
	    }

	    public List<Destination> getAllDestinations() {
	        return destinationRepository.findAll();
	    }

	    public Destination getDestinationById(Long id) {
	        return destinationRepository.findById(id).orElse(null);
	    }

	    public void deleteDestination(Long id) {
	        destinationRepository.deleteById(id);
	    }
	

}
