package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.ActivityRepository;
import com.spring.entity.Activity;

@Service
public class ActivityService {

	@Autowired
	private ActivityRepository activityRepository;
	
	

	public Activity saveActivity(Activity activity) {
		return activityRepository.save(activity);
	}

	public List<Activity> getAllActivities() {
		return activityRepository.findAll();
	}

	public Activity getActivityById(Long id) {
		return activityRepository.findById(id).orElse(null);
	}

	public void deleteActivity(Long id) {
		activityRepository.deleteById(id);
	}
}
