package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.entity.TravelPackage;
import com.spring.service.TravelPackageService;

@RestController
@RequestMapping("/packages")
public class TravelPackageController {

	@Autowired
	private TravelPackageService travelPackageService;

	@GetMapping
	public List<TravelPackage> getAllTravelPackages() {
		return travelPackageService.getAllTravelPackages();
	}

	@GetMapping("/{id}")
	public ResponseEntity<TravelPackage> getTravelPackageById(@PathVariable Long id) {
		TravelPackage travelPackage = travelPackageService.getTravelPackageById(id);
		return travelPackage != null ? ResponseEntity.ok(travelPackage) : ResponseEntity.notFound().build();
	}

	@PostMapping
	public ResponseEntity<TravelPackage> createTravelPackage(@RequestBody TravelPackage travelPackage) {
		TravelPackage savedTravelPackage = travelPackageService.saveTravelPackage(travelPackage);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedTravelPackage);
	}

	@PutMapping("/{id}")
	public ResponseEntity<TravelPackage> updateTravelPackage(@PathVariable Long id,
			@RequestBody TravelPackage travelPackageDetails) {
		TravelPackage travelPackage = travelPackageService.getTravelPackageById(id);
		if (travelPackage == null) {
			return ResponseEntity.notFound().build();
		}
		travelPackage.setName(travelPackageDetails.getName());
		// Update other properties as needed
		TravelPackage updatedTravelPackage = travelPackageService.saveTravelPackage(travelPackage);
		return ResponseEntity.ok(updatedTravelPackage);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteTravelPackage(@PathVariable Long id) {
		travelPackageService.deleteTravelPackage(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/{id}/itinerary")
	public ResponseEntity<String> printItinerary(@PathVariable Long id) {
		String itinerary = travelPackageService.printItinerary(id);
		return ResponseEntity.ok(itinerary);
	}

	@GetMapping("/{id}/passenger-list")
	public ResponseEntity<String> printPassengerList(@PathVariable Long id) {
		String passengerList = travelPackageService.printPassengerList(id);
		return ResponseEntity.ok(passengerList);
	}

	@GetMapping("/{id}/passengers/{passengerId}")
	public ResponseEntity<String> printPassengerDetails(@PathVariable Long id, @PathVariable Long passengerId) {
		String passengerDetails = travelPackageService.printPassengerDetails(id, passengerId);
		return ResponseEntity.ok(passengerDetails);
	}

	@GetMapping("/{id}/available-activities")
	public ResponseEntity<String> printAvailableActivities(@PathVariable Long id) {
		String availableActivities = travelPackageService.printAvailableActivities(id);
		return ResponseEntity.ok(availableActivities);
	}
}
