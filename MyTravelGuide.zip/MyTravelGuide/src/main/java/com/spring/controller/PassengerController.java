package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.entity.Passenger;
import com.spring.service.PassengerService;

@RestController
@RequestMapping("/passengers")
public class PassengerController {

	@Autowired
	private PassengerService passengerService;

	@GetMapping
	public List<Passenger> getAllPassengers() {
		return passengerService.getAllPassengers();
	}

	@GetMapping("/{id}")
	public ResponseEntity<Passenger> getPassengerById(@PathVariable Long id) {
		Passenger passenger = passengerService.getPassengerById(id);
		return passenger != null ? ResponseEntity.ok(passenger) : ResponseEntity.notFound().build();
	}

	@PostMapping
	public ResponseEntity<Passenger> createPassenger(@RequestBody Passenger passenger) {
		Passenger savedPassenger = passengerService.savePassenger(passenger);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedPassenger);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Passenger> updatePassenger(@PathVariable Long id, @RequestBody Passenger passengerDetails) {
		Passenger passenger = passengerService.getPassengerById(id);
		if (passenger == null) {
			return ResponseEntity.notFound().build();
		}
		passenger.setName(passengerDetails.getName());
		// Update other properties as needed
		Passenger updatedPassenger = passengerService.savePassenger(passenger);
		return ResponseEntity.ok(updatedPassenger);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePassenger(@PathVariable Long id) {
		passengerService.deletePassenger(id);
		return ResponseEntity.noContent().build();
	}
}
