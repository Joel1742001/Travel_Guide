package com.spring.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class TravelPackage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private int capacity;

	@OneToMany(mappedBy = "travelPackage", cascade = CascadeType.ALL)
	private List<Destination> itinerary = new ArrayList<>();

	@OneToMany(mappedBy = "travelPackage", cascade = CascadeType.ALL)
	private List<Passenger> passengers; // List of passengers enrolled in this travel package
	
	


	public TravelPackage(Long id, String name, int capacity, List<Destination> itinerary, List<Passenger> passengers) {
		super();
		this.id = id;
		this.name = name;
		this.capacity = capacity;
		this.itinerary = itinerary;
		this.passengers = passengers;
	}

	public TravelPackage() {
	    // Default constructor
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	 // Getter and setter for itinerary
    public List<Destination> getItinerary() {
        return itinerary;
    }

    public void setItinerary(List<Destination> itinerary) {
        this.itinerary = itinerary;
    }
	

	public List<Passenger> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}

}
