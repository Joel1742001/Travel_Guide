package com.spring.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Destination {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	@OneToMany(mappedBy = "destination", cascade = CascadeType.ALL)
	private List<Activity> activities;
	@ManyToOne
	@JoinColumn(name = "travel_package_id") // Name of the foreign key column in the Destination table
	private TravelPackage travelPackage; // Reference to the travel package this destination belongs to

	
	public Destination(Long id, String name, List<Activity> activities, TravelPackage travelPackage) {
		super();
		this.id = id;
		this.name = name;
		this.activities = activities;
		this.travelPackage = travelPackage;
	}

	public Destination() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Activity> getActivities() {
		return activities;
	}

	public void setActivities(List<Activity> activities) {
		this.activities = activities;
	}

	public TravelPackage getTravelPackage() {
		return travelPackage;
	}

	public void setTravelPackage(TravelPackage travelPackage) {
		this.travelPackage = travelPackage;
	}

}
